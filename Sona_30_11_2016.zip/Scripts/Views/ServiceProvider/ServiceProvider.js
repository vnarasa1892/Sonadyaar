﻿  $( function() {
      $("#txtDOB").datepicker();
  } );
